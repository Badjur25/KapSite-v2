<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Google Fonts -->
   <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .container {
            margin-top: 50px; /* Adjust the margin-top value as needed */
        }
        .form-group {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
    /* Center select box */
       .select-container {
            text-align: center;
        }
        .form-control {
            width: calc(50% - 20px);
            display: inline-block;
            margin-right: 10px;
            
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        if(isset($_POST["submit"])){
        $LastName = $_POST["LastName"];
        $FirstName = $_POST["FirstName"];
        $Email = $_POST["Email"];
        $password = $_POST["password"];
        $RepeatPassword = $_POST["repeat_password"];
        $errors = array();
 
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
 
        // validate if all fields are empty
        if (empty($LastName) OR empty($FirstName) OR empty($Email) OR empty($password) OR empty($RepeatPassword)) {
            array_push($errors,"All fields are required");
        }
        // validate if the email is not validated
        if (!filter_var($Email,FILTER_VALIDATE_EMAIL)){
            array_push($errors,"Email is not valid");
        }
        // password should not be less than 8
        if (strlen($password)<8) {
            array_push($errors,"Password must be atleast 8 characters long");
        }
        // check if password is the same
        if($password!= $RepeatPassword){
            array_push($errors,"Password does not match");           
        }
        require_once "database.php";
        $sql = "SELECT * FROM user WHERE email = '$Email'";
        $result = mysqli_query($conn, $sql);
        $rowCount = mysqli_num_rows($result);
        if ($rowCount>0){
            array_push($error, "email Already Exist!");
        }

        if (count($errors)> 0){
                foreach($errors as $error) {
                    echo"<div class='alert alert-danger'>$error</div>";
                }
             } else {
                require_once "database.php";
                $sql ="INSERT INTO user (LAST_NAME, FIRST_NAME, EMAIL, PASSWORD) VALUES (?, ?, ?, ?)";
                $stmt = mysqli_stmt_init($conn);
                $preparestmt = mysqli_stmt_prepare($stmt, $sql);
            if ($preparestmt) {
                mysqli_stmt_bind_param($stmt, "ssss", $LastName, $FirstName, $Email, $passwordHash);
                mysqli_stmt_execute($stmt);
                echo "<div class = 'alert alert-success'> You are Registered Successfully! </div>";
            } else {
                die("Something went wrong!");
            }
             }
            } 
             ?>
        <form action="registration.php" method="post">
            <div class="form-group">
                <input type="text" class="form-control" name="LastName" placeholder="Last Name">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="FirstName" placeholder="First Name">
            </div>
            <div class="form-group select-container">
                    <select class="form-control country">
                        <option value="" selected>Select Country</option>
                    </select>
                </div>
            <div class="form-group">
                <input type="text" class="form-control" name="City" placeholder="City">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="Province" placeholder="Province">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="Barangay" placeholder="Barangay">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="Email" placeholder="Email">
            </div>
            
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="repeat_password" placeholder="Repeat Password">
            </div>
            <div class="form-group text-center" >
                <input type="submit" class="btn btn-primary key" name="submit" placeholder="Submit ">
            </div>
        </form>
        <div class="text-center"><p>Already Registered? <a href="login.php">Login Here</a></p></div> <!-- Centering registration link -->
    </div>
</body>
 
<script> 
var config = {
  cUrl: 'https://api.countrystatecity.in/v1/countries',
  ckey: 'NHhvOEcyWk50N2Vna3VFTE00bFp3MjFKR0ZEOUhkZlg4RTk1MlJlaA=='
};

var countrySelect = document.querySelector('.country'),
  stateSelect = document.querySelector('.state'),
  citySelect = document.querySelector('.city');

function loadCountries() {
  let apiEndPoint = config.cUrl;
  fetch(apiEndPoint, {
          headers: {
              "X-CSCAPI-KEY": config.ckey
          }
      })
      .then(response => response.json())
      .then(data => {
          data.forEach(country => {
              const option = document.createElement('option');
              option.value = country.iso2;
              option.textContent = country.name;
              countrySelect.appendChild(option);
          });
      })
      .catch(error => console.error('Error loading countries:', error));

  stateSelect.disabled = true;
  citySelect.disabled = true;
  stateSelect.style.pointerEvents = 'none';
  citySelect.style.pointerEvents = 'none';
}

function loadStates() {
  stateSelect.disabled = false;
  citySelect.disabled = true;
  stateSelect.style.pointerEvents = 'auto';
  citySelect.style.pointerEvents = 'none';

  const selectedCountryCode = countrySelect.value;
  stateSelect.innerHTML = '<option value="">Select State</option>'; // Clear existing states
  citySelect.innerHTML = '<option value="">Select City</option>'; // Clear existing city options

  fetch(`${config.cUrl}/${selectedCountryCode}/states`, {
          headers: {
              "X-CSCAPI-KEY": config.ckey
          }
      })
      .then(response => response.json())
      .then(data => {
          data.forEach(state => {
              const option = document.createElement('option');
              option.value = state.iso2;
              option.textContent = state.name;
              stateSelect.appendChild(option);
          });
      })
      .catch(error => console.error('Error loading states:', error));
}

function loadCities() {
  citySelect.disabled = false;
  citySelect.style.pointerEvents = 'auto';

  const selectedCountryCode = countrySelect.value;
  const selectedStateCode = stateSelect.value;

  citySelect.innerHTML = '<option value="">Select City</option>'; // Clear existing city options

  fetch(`${config.cUrl}/${selectedCountryCode}/states/${selectedStateCode}/cities`, {
          headers: {
              "X-CSCAPI-KEY": config.ckey
          }
      })
      .then(response => response.json())
      .then(data => {
          data.forEach(city => {
              const option = document.createElement('option');
              option.value = city.iso2;
              option.textContent = city.name;
              citySelect.appendChild(option);
          });
      })
      .catch(error => console.error('Error loading cities:', error));
}

window.onload = loadCountries;
</script>



</html>