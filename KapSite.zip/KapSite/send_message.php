<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = "hatzkaplan@gmail.com";
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    $headers = "From: sender@example.com"; // Change this to the sender's email address

    if (mail($to, $subject, $message, $headers)) {
        echo "Message Sent";
    } else {
        echo "Failed to send message";
    }
} else {
    echo "Invalid request";
}
?>
