<?php
    session_start();
    // Set a session variable to indicate logout
    $_SESSION['logout_message'] = "You have logged out successfully.";
    // Destroy the session
    session_destroy();
    // Redirect the user to index.html
    header("location:index.html");
    exit; // It's a good practice to include exit after header redirection to prevent further execution
?>