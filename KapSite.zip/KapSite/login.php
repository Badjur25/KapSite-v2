<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Center form */
        .center-form {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        /* Add spacing between form groups */
        .form-group {
            margin-bottom: 20px;
        }
        /* Narrower input boxes */
        .form-control {
            width: calc(100% - 20px);
            display: inline-block;
            margin-right: 10px;
        }
        
    </style>
</head>
<body>
    <div class="center-form">
        <div class="form-container">
           <?php
if(isset($_POST["login"])){
    $email = $_POST["EMAIL"];
    $password = $_POST["PASSWORD"];
    require_once "database.php";
    $sql = "SELECT * FROM user WHERE EMAIL = '$email'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
    if ($user) {
        // Check if the password key is set in the POST data
        if(isset($_POST['PASSWORD'])) {
            // Access the PASSWORD key safely
            $password = $_POST['PASSWORD'];
        } else {
            // Handle the case when the key is not set
            $password = ""; // or any default value
        }
        // Use JavaScript to redirect the user
        echo "<script>window.location.href = 'index.html';</script>";
        die(); // Terminate script execution
    } else {
        // Display an error message if email does not match
        echo "<div class='alert alert-danger'>Email does not match</div>";
    }
}
?>

            <form action="login.php" method="post">
                <div class="form-group">
                    <label for="EMAIL">Email: </label>
                    <input type="EMAIL" name="EMAIL" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="PASSWORD">Password: </label>
                    <input type="PASSWORD" name="PASSWORD" class="form-control" required>
                </div>
                <div class="form-btn text-center" >
                    <input type="submit" value="Login" name="login" class="btn btn-primary">
                </div>
            </form>
            <div class="text-center"><p>Not Registered yet? <a href="registration.php">Register Here</a></p></div>
        </div>
    </div>
</body>
</html>
